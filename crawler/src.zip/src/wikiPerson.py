# coding=utf-8
import requests
import time
from bs4 import BeautifulSoup
import re
import urllib.request as ulbr
import pandas as pd
from src.utilAgent import *


class FigureRelation(object):
    def __init__(self, previous_person, current_person):
        self.previous_person = previous_person
        self.current_person = current_person


class WikiPerson(object):
    def __init__(self, base_key, deep, relation_path, context_path):
        self.__person_set = set()
        self.__baseUrl = 'https://zh.wikipedia.org'
        self.__baseKey = base_key
        self.figure_relation_list = []


def filter_person(link):
    title_attr = link.attrs['title']
    title_len = len(title_attr)
    if 'href' in link.attrs and title_len in [2, 3]:
        print(link)
        if title_attr[-1] in ('省', '市', '县', '区', '镇', '乡', '村') or title_attr in total_people_list:
            return None
        return title_attr


def get_relative_people(url):
    sleep_time = random.randint(10, 30)
    time.sleep(sleep_time)
    headers['User-Agent'] = choose_ua()
    try:
        response = requests.get(url, headers=headers)
    except:
        print('访问失败: ', response.status_code)
        time.sleep(60)
        return []
    response.encoding = 'utf-8'
    text = response.text
    html = BeautifulSoup(text, "lxml")
    content = html.find("div", {"id": "bodyContent"})
    person_list = []
    for link in content.findAll("a", href=re.compile("^(/wiki/)((?!:).)*$")):
        person = filter_person(link)
        if person:
            person_list.append(person)
    return list(set(person_list))


def construct_relation(person_name, relative_person_list):
    return [[person_name, relative_person_name] for relative_person_name in relative_person_list]


result = []

if __name__ == '__main__':
    total_people_list = ['陈独秀']
    base_url = 'https://zh.wikipedia.org/wiki/'
    current_person_list = ['陈独秀']
    for person in current_person_list:
        url = base_url + ulbr.pathname2url(person)
        relative_people = get_relative_people(url)
        if relative_people:
            total_people_list.extend(relative_people)
            relative_people.reverse()
            current_person_list.extend(relative_people)
            result.extend(construct_relation(person, relative_people))
            current_person_list.remove(person)
        if len(total_people_list) > 20000:
            pd.DataFrame(result).to_csv("figure_relation.csv", index=None)
            break
